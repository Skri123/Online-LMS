const Payment = require('../models/Payment');

// Create a payment record
exports.createPayment = async (req, res) => {
  try {
    const payment = new Payment(req.body);
    await payment.save();
    res.status(201).json(payment);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// Get payments for a user
exports.getPaymentsByUser = async (req, res) => {
  try {
    const payments = await Payment.find({ user: req.params.userId }).populate('course', 'title');
    res.json(payments);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
