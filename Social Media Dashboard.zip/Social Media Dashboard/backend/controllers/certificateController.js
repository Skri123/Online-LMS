const Certificate = require('../models/Certificate');

// Generate a certificate
exports.generateCertificate = async (req, res) => {
  try {
    const { user, course, certificateUrl } = req.body;

    const certificate = new Certificate({
      user,
      course,
      certificateUrl: certificateUrl || '',
    });

    await certificate.save();
    res.status(201).json(certificate);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// Get certificates for a user
exports.getCertificatesByUser = async (req, res) => {
  try {
    const certificates = await Certificate.find({ user: req.params.userId }).populate('course', 'title');
    res.json(certificates);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
