const mongoose = require('mongoose');

const certificateSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  course: { type: mongoose.Schema.Types.ObjectId, ref: 'Course', required: true },
  dateIssued: { type: Date, default: Date.now },
  certificateUrl: { type: String }, // URL to the generated certificate PDF/image
}, { timestamps: true });

module.exports = mongoose.model('Certificate', certificateSchema);
