const express = require('express');
const router = express.Router();
const quizController = require('../controllers/quizController');

// Create a new quiz
router.post('/', quizController.createQuiz);

// Get all quizzes for a course
router.get('/course/:courseId', quizController.getQuizzesByCourse);

// Get quiz by ID
router.get('/:id', quizController.getQuizById);

// Submit quiz answers and get score
router.post('/:id/submit', quizController.submitQuiz);

module.exports = router;
