const express = require('express');
const router = express.Router();
const paymentController = require('../controllers/paymentController');

// Create a payment record
router.post('/', paymentController.createPayment);

// Get payments for a user
router.get('/user/:userId', paymentController.getPaymentsByUser);

module.exports = router;
