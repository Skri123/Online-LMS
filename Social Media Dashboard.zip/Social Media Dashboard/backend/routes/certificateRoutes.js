const express = require('express');
const router = express.Router();
const certificateController = require('../controllers/certificateController');

// Generate a certificate
router.post('/', certificateController.generateCertificate);

// Get certificates for a user
router.get('/user/:userId', certificateController.getCertificatesByUser);

module.exports = router;
