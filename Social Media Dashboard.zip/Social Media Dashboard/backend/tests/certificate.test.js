const request = require('supertest');
const app = require('../server'); // Adjust path if needed
const mongoose = require('mongoose');

describe('Certificate API Endpoints', () => {
  beforeAll(async () => {
    // Connect to test database
    await mongoose.connect(process.env.MONGODB_URI_TEST, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
  });

  afterAll(async () => {
    await mongoose.connection.close();
  });

  it('should create a new certificate', async () => {
    const res = await request(app)
      .post('/api/certificates')
      .send({
        user: 'testuserid',
        course: 'testcourseid',
        certificateUrl: 'http://example.com/certificate.pdf',
      });
    expect(res.statusCode).toEqual(201);
    expect(res.body).toHaveProperty('_id');
  });

  it('should get certificates for a user', async () => {
    const res = await request(app).get('/api/certificates/user/testuserid');
    expect(res.statusCode).toEqual(200);
    expect(Array.isArray(res.body)).toBe(true);
  });
});
