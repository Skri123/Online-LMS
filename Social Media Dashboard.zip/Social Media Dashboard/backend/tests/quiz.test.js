const request = require('supertest');
const app = require('../server'); // Adjust path if needed
const mongoose = require('mongoose');

describe('Quiz API Endpoints', () => {
  beforeAll(async () => {
    // Connect to test database
    await mongoose.connect(process.env.MONGODB_URI_TEST, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
  });

  afterAll(async () => {
    await mongoose.connection.close();
  });

  it('should create a new quiz', async () => {
    const res = await request(app)
      .post('/api/quizzes')
      .send({
        course: 'testcourseid',
        title: 'Test Quiz',
        questions: [
          {
            questionText: 'What is 2+2?',
            options: ['3', '4', '5'],
            correctAnswerIndex: 1,
          },
        ],
      });
    expect(res.statusCode).toEqual(201);
    expect(res.body).toHaveProperty('_id');
  });

  it('should get quizzes for a course', async () => {
    const res = await request(app).get('/api/quizzes/course/testcourseid');
    expect(res.statusCode).toEqual(200);
    expect(Array.isArray(res.body)).toBe(true);
  });
});
