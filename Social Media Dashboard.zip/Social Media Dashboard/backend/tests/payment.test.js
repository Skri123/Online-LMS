const request = require('supertest');
const app = require('../server'); // Adjust path if needed
const mongoose = require('mongoose');

describe('Payment API Endpoints', () => {
  beforeAll(async () => {
    // Connect to test database
    await mongoose.connect(process.env.MONGODB_URI_TEST, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
  });

  afterAll(async () => {
    await mongoose.connection.close();
  });

  it('should create a new payment', async () => {
    const res = await request(app)
      .post('/api/payments')
      .send({
        user: 'testuserid',
        course: 'testcourseid',
        amount: 100,
        paymentMethod: 'Stripe',
        paymentStatus: 'completed',
        transactionId: 'txn_123456',
      });
    expect(res.statusCode).toEqual(201);
    expect(res.body).toHaveProperty('_id');
  });

  it('should get payments for a user', async () => {
    const res = await request(app).get('/api/payments/user/testuserid');
    expect(res.statusCode).toEqual(200);
    expect(Array.isArray(res.body)).toBe(true);
  });
});
