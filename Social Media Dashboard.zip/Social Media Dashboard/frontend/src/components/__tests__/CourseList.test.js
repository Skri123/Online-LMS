import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import axios from 'axios';
import CourseList from '../CourseList';

jest.mock('axios');

describe('CourseList Component', () => {
  test('renders loading state initially', () => {
    axios.get.mockResolvedValue({ data: [] });
    render(<CourseList />);
    expect(screen.getByText(/Loading courses.../i)).toBeInTheDocument();
  });

  test('renders courses after fetch', async () => {
    const courses = [
      {
        _id: '1',
        title: 'Test Course',
        description: 'Test Description',
        instructor: { name: 'Test Instructor' },
        price: 0,
        isPremium: false,
      },
    ];
    axios.get.mockResolvedValue({ data: courses });
    render(<CourseList />);
    await waitFor(() => {
      expect(screen.getByText('Test Course')).toBeInTheDocument();
      expect(screen.getByText('Test Description')).toBeInTheDocument();
      expect(screen.getByText(/Instructor: Test Instructor/i)).toBeInTheDocument();
      expect(screen.getByText(/Price: Free/i)).toBeInTheDocument();
    });
  });

  test('renders error message on fetch failure', async () => {
    axios.get.mockRejectedValue(new Error('Network Error'));
    render(<CourseList />);
    await waitFor(() => {
      expect(screen.getByText(/Failed to fetch courses/i)).toBeInTheDocument();
    });
  });
});
