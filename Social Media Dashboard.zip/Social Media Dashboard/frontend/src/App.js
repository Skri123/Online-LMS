import React from 'react';
import { Routes, Route } from 'react-router-dom';
import CourseList from './components/CourseList';

function App() {
  return (
    <div>
      <h1>Online Learning Management System</h1>
      <Routes>
        <Route path="/" element={<CourseList />} />
        {/* Additional routes for course details, quizzes, certificates, payments, etc. will be added here */}
      </Routes>
    </div>
  );
}

export default App;
